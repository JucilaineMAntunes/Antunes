<?php
$accessKey = 'AKIAZ5EHQACBJ7TEAT5L';
$secretKey = '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';
$region = 'us-east-1';
$bucket = 'bancocloud.local';
$arqName =  'logo.jpg';
$linkestatico = 'http://bancocloud.local.s3-website-us-east-1.amazonaws.com'
?>
